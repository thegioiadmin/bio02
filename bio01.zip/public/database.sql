-- ==============================================================================
-- DATABASE SCHEMA: NỀN TẢNG BIO LINK & TRANG CÁ NHÂN CHUYÊN NGHIỆP
-- IMPORT TRỰC TIẾP VÀO PHPMYADMIN TRÊN HOSTING INET / CPANEL
-- ==============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. BẢNG USERS (TÀI KHOẢN NGƯỜI DÙNG & QUẢN TRỊ VIÊN)
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `email` VARCHAR(150) NULL,
  `phone` VARCHAR(50) NULL,
  `name` VARCHAR(255) NULL,
  `avatar_url` TEXT NULL,
  `role` VARCHAR(50) DEFAULT 'user',
  `is_staff` TINYINT(1) DEFAULT 0,
  `staff_position` VARCHAR(50) NULL,
  `staff_role_badge` VARCHAR(50) NULL,
  `staff_permissions` TEXT NULL,
  `staff_department` VARCHAR(100) NULL,
  `staff_title` VARCHAR(100) NULL,
  `status` VARCHAR(50) DEFAULT 'active',
  `plan` VARCHAR(50) DEFAULT 'free',
  `plan_expires_at` VARCHAR(50) NULL,
  `verified` TINYINT(1) DEFAULT 0,
  `verification_status` VARCHAR(50) DEFAULT 'unverified',
  `verification_request_id` VARCHAR(100) NULL,
  `verification_rejection_reason` TEXT NULL,
  `balance` BIGINT DEFAULT 0,
  `account_type` VARCHAR(50) DEFAULT 'personal',
  `business_name` VARCHAR(255) NULL,
  `tax_code` VARCHAR(50) NULL,
  `industry` VARCHAR(100) NULL,
  `custom_domain` VARCHAR(255) NULL,
  `bio_count` INT DEFAULT 1,
  `total_views` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_username` (`username`),
  INDEX `idx_email` (`email`),
  INDEX `idx_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. BẢNG BIOS (CẤU HÌNH TRANG BIO LINK CỦA TỪNG NGƯỜI DÙNG)
CREATE TABLE IF NOT EXISTS `bios` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `config` LONGTEXT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_bio_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. BẢNG SYSTEM_CONFIG (CẤU HÌNH HỆ THỐNG TOÀN DIỆN, BẢO TRÌ, GÓI DỊCH VỤ)
CREATE TABLE IF NOT EXISTS `system_config` (
  `id` INT PRIMARY KEY DEFAULT 1,
  `config` LONGTEXT NOT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. BẢNG TEMPLATES (KHO GIAO DIỆN MẪU ĐƯỢC ADMIN QUẢN LÝ / CẬP NHẬT)
CREATE TABLE IF NOT EXISTS `templates` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NULL,
  `description` TEXT NULL,
  `data` LONGTEXT NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. BẢNG TRANSACTIONS (LỊCH SỬ GIAO DỊCH, NẠP TIỀN, CỘNG TIỀN THỦ CÔNG)
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `user_id` VARCHAR(100) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `amount` BIGINT NOT NULL,
  `description` TEXT NULL,
  `status` VARCHAR(50) DEFAULT 'completed',
  `payment_method` VARCHAR(50) DEFAULT 'balance',
  `reference_code` VARCHAR(100) NULL,
  `receipt_note` TEXT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_tx_user` (`user_id`),
  INDEX `idx_tx_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. BẢNG SUPPORT_TICKETS (HỖ TRỢ KHÁCH HÀNG & CSKH)
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `user_id` VARCHAR(100) NOT NULL,
  `user_name` VARCHAR(255) NULL,
  `user_email` VARCHAR(150) NULL,
  `user_phone` VARCHAR(50) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) DEFAULT 'other',
  `priority` VARCHAR(50) DEFAULT 'medium',
  `status` VARCHAR(50) DEFAULT 'new',
  `assigned_staff_id` VARCHAR(100) NULL,
  `assigned_staff_name` VARCHAR(255) NULL,
  `messages` LONGTEXT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_ticket_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. BẢNG STAFF_AUDIT_LOGS (NHẬT KÝ HOẠT ĐỘNG CỦA ADMIN VÀ NHÂN VIÊN)
CREATE TABLE IF NOT EXISTS `staff_audit_logs` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `staff_id` VARCHAR(100) NULL,
  `staff_name` VARCHAR(255) NULL,
  `action` VARCHAR(255) NOT NULL,
  `target_type` VARCHAR(50) NULL,
  `target_id` VARCHAR(100) NULL,
  `details` TEXT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_log_staff` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. BẢNG VERIFICATION_REQUESTS (YÊU CẦU XÁC MINH DANH TÍNH TÍCH XANH KYC)
CREATE TABLE IF NOT EXISTS `verification_requests` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `user_id` VARCHAR(100) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `user_name` VARCHAR(255) NULL,
  `user_email` VARCHAR(150) NULL,
  `user_phone` VARCHAR(50) NULL,
  `user_plan` VARCHAR(50) DEFAULT 'free',
  `entity_type` VARCHAR(50) DEFAULT 'personal',
  `personal_docs` LONGTEXT NULL,
  `business_docs` LONGTEXT NULL,
  `status` VARCHAR(50) DEFAULT 'pending',
  `reviewed_by` VARCHAR(100) NULL,
  `reviewer_name` VARCHAR(255) NULL,
  `rejection_reason` TEXT NULL,
  `notes` TEXT NULL,
  `submitted_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` DATETIME NULL,
  INDEX `idx_verif_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. BẢNG ARTICLES (BÀI VIẾT TIN TỨC & HƯỚNG DẪN)
CREATE TABLE IF NOT EXISTS `articles` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `category` VARCHAR(100) NULL,
  `excerpt` TEXT NULL,
  `content` LONGTEXT NOT NULL,
  `cover_image` TEXT NULL,
  `author_name` VARCHAR(255) DEFAULT 'Ban Biên Tập',
  `is_published` TINYINT(1) DEFAULT 1,
  `view_count` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- DỮ LIỆU KHỞI TẠO MẶC ĐỊNH (TÀI KHOẢN ADMIN: thegioiadmin / admin123 & CẤU HÌNH HỆ THỐNG)
-- ==============================================================================

INSERT INTO `users` (
  `id`, `username`, `password`, `email`, `phone`, `name`, `avatar_url`, `role`, 
  `is_staff`, `staff_position`, `staff_role_badge`, `staff_permissions`, `staff_department`, 
  `staff_title`, `status`, `plan`, `verified`, `balance`, `bio_count`, `total_views`, `created_at`
) VALUES (
  'usr_admin_01', 
  'thegioiadmin', 
  'admin123', 
  'thegioiadmin@gmail.com', 
  '0988889999', 
  'Quản Trị Viên (Admin)', 
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop', 
  'admin', 
  1, 
  'admin', 
  'ADMIN', 
  '[\"support\",\"finance\",\"moderation\",\"users\",\"analytics\"]', 
  'Ban Quản Trị Tối Cao', 
  'Quản Trị Viên Toàn Quyền', 
  'active', 
  'vip', 
  1, 
  5000000, 
  6, 
  128600, 
  NOW()
) ON DUPLICATE KEY UPDATE `role` = 'admin', `plan` = 'vip', `verified` = 1;

-- Cấu hình hệ thống toàn diện mặc định (Tên miền, Thương hiệu, VietQR, SePay, Footer, Banner, Popup)
INSERT INTO `system_config` (`id`, `config`, `updated_at`) 
VALUES (
  1, 
  '{\"mainDomain\":\"trangcanhan.com\",\"cnameTarget\":\"cname.trangcanhan.com\",\"defaultUserPlan\":\"free\",\"brandName\":\"TRANG CÁ NHÂN\",\"brandTagline\":\"Nền tảng tạo TRANG CÁ NHÂN #1 tại Việt Nam. Giúp bạn kết nối tất cả liên kết trong một trang duy nhất.\",\"logoUrl\":\"\",\"faviconUrl\":\"\",\"announcementActive\":true,\"announcementText\":\"🎉 Chào mừng đến với TRANG CÁ NHÂN - Nền tảng tạo Bio Link & Trang Cá Nhân chuyên nghiệp 2026. Tặng thêm +10% khi nạp ví qua VietQR Napas 24/7!\",\"popupModal\":{\"enabled\":true,\"title\":\"Chào Mừng Đến Với TRANG CÁ NHÂN\",\"badge\":\"THÔNG BÁO TỪ BAN QUẢN TRỊ\",\"content\":\"🎉 Hệ thống vừa nâng cấp phiên bản 2026 với kho hơn 50+ mẫu giao diện mới, tích hợp thanh toán VietQR tự động và ưu đãi tặng thêm +10% giá trị nạp ví. Chúc bạn xây dựng trang Bio cá nhân thật ấn tượng và thành công!\",\"buttonText\":\"Khám Phá Bảng Giá & Ưu Đãi\",\"buttonLink\":\"#pricing\",\"imageUrl\":\"\"},\"defaultBioFooterText\":\"Đăng ký miễn phí TRANG CÁ NHÂN\",\"defaultBioFooterLink\":\"http://trangcanhan.com\",\"autoPaymentConfig\":{\"enabled\":true,\"provider\":\"sepay\",\"apiKey\":\"\",\"accountNumber\":\"0988889999\",\"bankCode\":\"MB\",\"accountName\":\"CONG TY TRANG CA NHAN\",\"momoNumber\":\"0988889999\",\"momoName\":\"TRANG CA NHAN\",\"webhookUrl\":\"https://trangcanhan.com/api/webhook/sepay\",\"autoUpgradePlanEnabled\":true,\"autoDepositBalanceEnabled\":true,\"depositPrefix\":\"NAP\",\"proPlanPrefix\":\"PRO\",\"vipPlanPrefix\":\"VIP\",\"minDepositAmount\":10000,\"matchUsernameOrUserId\":true,\"sendSuccessEmail\":true,\"playAudioAlert\":true},\"footerConfig\":{\"brandName\":\"TRANG CÁ NHÂN\",\"brandLink\":\"http://trangcanhan.com\",\"brandTagline\":\"Nền tảng tạo TRANG CÁ NHÂN #1 tại Việt Nam.\\nGiúp bạn kết nối tất cả liên kết trong một trang duy nhất.\",\"copyrightText\":\"© 2026 TRANG CÁ NHÂN. Tất cả quyền được bảo lưu.\",\"copyrightLink\":\"http://trangcanhan.com\",\"madeWithText\":\"Made with ❤️ Thế giới Admin\",\"madeWithLink\":\"https://facebook.com/thegioieditor\",\"govCertification\":{\"enabled\":true,\"imageUrl\":\"/bo-cong-thuong.svg\",\"targetUrl\":\"http://online.gov.vn/\",\"altText\":\"Đã thông báo Bộ Công Thương\",\"width\":140}}}',
  NOW()
) ON DUPLICATE KEY UPDATE `updated_at` = NOW();

SET FOREIGN_KEY_CHECKS = 1;
