<?php
/**
 * ==============================================================================
 * CẤU HÌNH KẾT NỐI CƠ SỞ DỮ LIỆU MYSQL / PHPMYADMIN (DÀNH CHO HOSTING INET / CPANEL)
 * ==============================================================================
 * 
 * HƯỚNG DẪN CẤU HÌNH TRÊN HOSTING INET:
 * 1. Đăng nhập vào trang quản lý Hosting cPanel / DirectAdmin của iNET.
 * 2. Tìm mục "MySQL Databases" (Cơ sở dữ liệu MySQL):
 *    - Tạo 1 Database mới (Ví dụ: `inetuser_biolink`).
 *    - Tạo 1 User MySQL mới và đặt mật khẩu (Ví dụ: user `inetuser_admin`, pass: `MatKhau@123`).
 *    - Gán User vừa tạo vào Database và cấp "ALL PRIVILEGES" (Mọi quyền).
 * 3. Điền các thông tin vừa tạo vào các biến bên dưới:
 */

define('DB_HOST', 'localhost');              // Thông thường trên iNET là 'localhost' hoặc '127.0.0.1'
define('DB_PORT', 3306);                     // Cổng mặc định MySQL: 3306
define('DB_NAME', 'biolink_db');             // Tên Database bạn đã tạo trong cPanel (ví dụ: inet_biolink)
define('DB_USER', 'root');                   // Tên User Database bạn đã tạo (ví dụ: inet_admin)
define('DB_PASS', '');                       // Mật khẩu User Database

// Thiết lập múi giờ Việt Nam
date_default_timezone_set('Asia/Ho_Chi_Minh');

// CORS Headers cho phép gọi API từ frontend
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
