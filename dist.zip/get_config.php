<?php
/**
 * API: Lấy cấu hình hệ thống toàn diện & Kho mẫu giao diện từ MySQL
 */
require_once __DIR__ . '/db.php';

$pdo = getPDO();

if ($pdo) {
    $stmt = $pdo->query("SELECT config FROM system_config WHERE id = 1 LIMIT 1");
    $row = $stmt->fetch();
    $config = [];
    if ($row && !empty($row['config'])) {
        $config = json_decode($row['config'], true) ?: [];
    }

    // Lấy thêm danh sách mẫu tùy chỉnh từ bảng templates nếu có
    $stmtTpl = $pdo->query("SELECT * FROM templates WHERE is_active = 1 ORDER BY updated_at DESC");
    $dbTemplates = $stmtTpl->fetchAll();
    if (!empty($dbTemplates)) {
        $tplList = [];
        foreach ($dbTemplates as $t) {
            $tplData = json_decode($t['data'], true);
            if ($tplData && is_array($tplData)) {
                $tplList[] = array_merge($tplData, [
                    'id' => $t['id'],
                    'name' => $t['name'],
                    'category' => $t['category'] ?? $tplData['category'] ?? 'creative',
                    'description' => $t['description'] ?? $tplData['description'] ?? ''
                ]);
            }
        }
        if (!empty($tplList)) {
            $config['customTemplates'] = $tplList;
        }
    }

    if (empty($config['articles'])) {
        $db = readJsonDatabase();
        if (!empty($db['articles'])) {
            $config['articles'] = $db['articles'];
        }
    }

    // Chuẩn hóa trạng thái banner thông báo chạy dòng đầu trang
    if (isset($config['announcementActive'])) {
        $val = $config['announcementActive'];
        $config['announcementActive'] = ($val === true || $val === 'true' || $val === 1 || $val === '1');
    } else {
        $config['announcementActive'] = false;
    }

    // Chuẩn hóa popup thông báo hệ thống
    if (isset($config['popupModal']) && is_array($config['popupModal'])) {
        if (isset($config['popupModal']['enabled'])) {
            $pval = $config['popupModal']['enabled'];
            $config['popupModal']['enabled'] = ($pval === true || $pval === 'true' || $pval === 1 || $pval === '1');
        } else {
            $config['popupModal']['enabled'] = false;
        }
    }

    // Chuẩn hóa bảo trì hệ thống
    if (isset($config['maintenanceMode'])) {
        $mval = $config['maintenanceMode'];
        $config['maintenanceMode'] = ($mval === true || $mval === 'true' || $mval === 1 || $mval === '1');
    }
    if (isset($config["maintenanceConfig"]) && is_array($config["maintenanceConfig"])) {
        if (isset($config["maintenanceConfig"]["globalMaintenance"])) {
            $gmval = $config["maintenanceConfig"]["globalMaintenance"];
            $config["maintenanceConfig"]["globalMaintenance"] = ($gmval === true || $gmval === "true" || $gmval === 1 || $gmval === "1");
        }
        if (!isset($config["maintenanceConfig"]["modules"]["homepage"])) {
            $config["maintenanceConfig"]["modules"]["homepage"] = [
                "key" => "homepage",
                "name" => "Trang Chủ (Landing Page)",
                "description" => "Tạm khóa nội dung ngoài trang chủ với thông báo bảo trì, Logo và Menu Header vẫn hiển thị bình thường",
                "isUnderMaintenance" => false,
                "maintenanceTitle" => "Trang Chủ Đang Nâng Cấp & Bảo Trì",
                "maintenanceMessage" => "Trang chủ TRANG CÁ NHÂN đang được nâng cấp giao diện và bổ sung thêm các tính năng mới. Các dịch vụ đăng nhập, quản lý bio và bảng giá vẫn hoạt động bình thường.",
                "expectedEndTime" => "15:00 Hôm nay",
                "allowAdminBypass" => true
            ];
        }
    }

    // Tự động nhận diện tên miền thực tế trên Hosting (Hostinger / cPanel)
    $httpHost = $_SERVER['HTTP_HOST'] ?? '';
    $cleanHost = preg_replace('/:\d+$/', '', $httpHost);
    $isAiStudio = (strpos($cleanHost, 'run.app') !== false || strpos($cleanHost, 'ais-') !== false || strpos($cleanHost, 'localhost') !== false);
    if (empty($config['mainDomain']) || strpos($config['mainDomain'], 'run.app') !== false || strpos($config['mainDomain'], 'ais-dev') !== false) {
        if (!empty($cleanHost) && !$isAiStudio) {
            $config['mainDomain'] = $cleanHost;
        } else if (empty($config['mainDomain'])) {
            $config['mainDomain'] = !empty($cleanHost) ? $cleanHost : 'trangcanhan.com';
        }
    }

    sendJsonResponse([
        'status' => 'success',
        'success' => true,
        'config' => $config
    ]);
} else {
    $db = readJsonDatabase();
    $config = $db['systemConfig'] ?? [];
    if (!empty($db['customTemplates'])) {
        $config['customTemplates'] = $db['customTemplates'];
    }
    if (empty($config['articles']) && !empty($db['articles'])) {
        $config['articles'] = $db['articles'];
    }
    if (isset($config['announcementActive'])) {
        $val = $config['announcementActive'];
        $config['announcementActive'] = ($val === true || $val === 'true' || $val === 1 || $val === '1');
    } else {
        $config['announcementActive'] = false;
    }

    // Chuẩn hóa popup thông báo hệ thống
    if (isset($config['popupModal']) && is_array($config['popupModal'])) {
        if (isset($config['popupModal']['enabled'])) {
            $pval = $config['popupModal']['enabled'];
            $config['popupModal']['enabled'] = ($pval === true || $pval === 'true' || $pval === 1 || $pval === '1');
        } else {
            $config['popupModal']['enabled'] = false;
        }
    }

    // Chuẩn hóa bảo trì hệ thống
    if (isset($config['maintenanceMode'])) {
        $mval = $config['maintenanceMode'];
        $config['maintenanceMode'] = ($mval === true || $mval === 'true' || $mval === 1 || $mval === '1');
    }
    if (isset($config["maintenanceConfig"]) && is_array($config["maintenanceConfig"])) {
        if (isset($config["maintenanceConfig"]["globalMaintenance"])) {
            $gmval = $config["maintenanceConfig"]["globalMaintenance"];
            $config["maintenanceConfig"]["globalMaintenance"] = ($gmval === true || $gmval === "true" || $gmval === 1 || $gmval === "1");
        }
        if (!isset($config["maintenanceConfig"]["modules"]["homepage"])) {
            $config["maintenanceConfig"]["modules"]["homepage"] = [
                "key" => "homepage",
                "name" => "Trang Chủ (Landing Page)",
                "description" => "Tạm khóa nội dung ngoài trang chủ với thông báo bảo trì, Logo và Menu Header vẫn hiển thị bình thường",
                "isUnderMaintenance" => false,
                "maintenanceTitle" => "Trang Chủ Đang Nâng Cấp & Bảo Trì",
                "maintenanceMessage" => "Trang chủ TRANG CÁ NHÂN đang được nâng cấp giao diện và bổ sung thêm các tính năng mới. Các dịch vụ đăng nhập, quản lý bio và bảng giá vẫn hoạt động bình thường.",
                "expectedEndTime" => "15:00 Hôm nay",
                "allowAdminBypass" => true
            ];
        }
    }

    // Tự động nhận diện tên miền thực tế trên Hosting (Hostinger / cPanel)
    $httpHost = $_SERVER['HTTP_HOST'] ?? '';
    $cleanHost = preg_replace('/:\d+$/', '', $httpHost);
    $isAiStudio = (strpos($cleanHost, 'run.app') !== false || strpos($cleanHost, 'ais-') !== false || strpos($cleanHost, 'localhost') !== false);
    if (empty($config['mainDomain']) || strpos($config['mainDomain'], 'run.app') !== false || strpos($config['mainDomain'], 'ais-dev') !== false) {
        if (!empty($cleanHost) && !$isAiStudio) {
            $config['mainDomain'] = $cleanHost;
        } else if (empty($config['mainDomain'])) {
            $config['mainDomain'] = !empty($cleanHost) ? $cleanHost : 'trangcanhan.com';
        }
    }

    sendJsonResponse([
        'status' => 'success',
        'success' => true,
        'config' => $config
    ]);
}
